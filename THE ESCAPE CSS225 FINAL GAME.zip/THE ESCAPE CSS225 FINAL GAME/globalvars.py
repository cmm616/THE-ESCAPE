


def Init():
    global player
    global curr_chap
    global Game_is_Running
    global Player_inventory

    player = "default"
    curr_chap = 1
    Game_is_Running = True
    Player_inventory = []
    Player_inventory.clear()