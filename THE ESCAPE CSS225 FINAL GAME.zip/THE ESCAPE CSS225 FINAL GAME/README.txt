# vim: set ft=rst:
Created by Corinthain Miles
Final Project for CSS-225-40 - 90550.202490
"The Escape" is a textbased mystery puzzle. Your tasked with finding out your identity along with the reason your were imprisoned.
The program consist of 7 files, 5 chapter files, and a global varibal file along with a game flow file.
The five chapter files act as the prompts for the player as the progress through them game.
The global variable file acts as the glue for my program, it contains the players inventory functionality.
the game flow file also acts as the glue for the transition between files.
This program uses python and can be dowloaded and played on any application that can host python code.
How to run:
you must have all python files downloaded and you must run the game from the game flow file.
Be sure to only imput number characters for your decisions withen the terminal.

See https://help.pythonanywhere.com/ (or click the "Help" link at the top
right) for help on how to use PythonAnywhere, including tips on copying and
pasting from consoles, and writing your own web applications.
